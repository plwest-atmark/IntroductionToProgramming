﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASC.Models.BaseTypes
{
    public interface IAuditTracker
    {
    }
}
