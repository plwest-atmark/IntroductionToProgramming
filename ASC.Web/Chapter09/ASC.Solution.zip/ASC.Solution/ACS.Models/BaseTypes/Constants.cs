﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ASC.Models.BaseTypes
{
    public static class Constants
    {
    }

    public enum Roles
    {
        Admin, Engineer, User
    }
}
